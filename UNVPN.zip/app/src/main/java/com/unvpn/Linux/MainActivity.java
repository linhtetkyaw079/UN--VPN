package com.unvpn.Linux;

import android.animation.*;
import android.app.*;
import android.app.AlertDialog;
import android.content.*;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.*;
import android.graphics.*;
import android.graphics.Typeface;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.localbroadcastmanager.*;
import com.shashank.sony.fancytoastlib.*;
import de.blinkt.openvpn.*;
import de.hdodenhof.circleimageview.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import android.content.BroadcastReceiver;
import android.net.VpnService;
import android.os.RemoteException;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import de.blinkt.openvpn.OpenVpnApi;
import de.blinkt.openvpn.core.OpenVPNService;
import de.blinkt.openvpn.core.OpenVPNThread;
import de.blinkt.openvpn.core.ProfileManager;
import java.lang.Thread.UncaughtExceptionHandler;

public class MainActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	
	private boolean vpnStart = false;
	private  Server server;
	private  OpenVPNThread vpnThread = new OpenVPNThread();
	private  OpenVPNService vpnService = new OpenVPNService();
	private  SharedPreference preference;
	private  static final String TAG = "Test";
	private String place = "";
	private  Thread.UncaughtExceptionHandler defaultUEH;
	private double n = 0;
	private double time = 0;
	private double ping = 0;
	private boolean startr = false;
	private String str = "";
	
	private ArrayList<String> conList = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> lm = new ArrayList<>();
	
	private LinearLayout linear19;
	private LinearLayout linear24;
	private LinearLayout linear21;
	private LinearLayout linear20;
	private LinearLayout linear1;
	private LinearLayout linear7;
	private LinearLayout linear31;
	private LinearLayout linear27;
	private TextView textview9;
	private CircleImageView circleimageview1;
	private LinearLayout linear5;
	private LinearLayout linear30;
	private TextView textview1;
	private Spinner spinner1;
	private LinearLayout linear26;
	private LinearLayout linear29;
	private LinearLayout linear28;
	private LinearLayout linear25;
	private TextView textview3;
	private ProgressBar progressbar1;
	private TextView textview4;
	
	private Intent i = new Intent();
	private AlertDialog.Builder dialog;
	private TimerTask t;
	private TimerTask tt;
	private RequestNetwork net;
	private RequestNetwork.RequestListener _net_request_listener;
	private RequestNetwork ner;
	private RequestNetwork.RequestListener _ner_request_listener;
	private RequestNetwork nett;
	private RequestNetwork.RequestListener _nett_request_listener;
	private TimerTask ping_timer;
	private TimerTask ti;
	private ProgressDialog dia;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear19 = findViewById(R.id.linear19);
		linear24 = findViewById(R.id.linear24);
		linear21 = findViewById(R.id.linear21);
		linear20 = findViewById(R.id.linear20);
		linear1 = findViewById(R.id.linear1);
		linear7 = findViewById(R.id.linear7);
		linear31 = findViewById(R.id.linear31);
		linear27 = findViewById(R.id.linear27);
		textview9 = findViewById(R.id.textview9);
		circleimageview1 = findViewById(R.id.circleimageview1);
		linear5 = findViewById(R.id.linear5);
		linear30 = findViewById(R.id.linear30);
		textview1 = findViewById(R.id.textview1);
		spinner1 = findViewById(R.id.spinner1);
		linear26 = findViewById(R.id.linear26);
		linear29 = findViewById(R.id.linear29);
		linear28 = findViewById(R.id.linear28);
		linear25 = findViewById(R.id.linear25);
		textview3 = findViewById(R.id.textview3);
		progressbar1 = findViewById(R.id.progressbar1);
		textview4 = findViewById(R.id.textview4);
		dialog = new AlertDialog.Builder(this);
		net = new RequestNetwork(this);
		ner = new RequestNetwork(this);
		nett = new RequestNetwork(this);
		
		circleimageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				View cus_t = getLayoutInflater().inflate(R.layout.cus_t, null);
				final PopupWindow pop_up = new PopupWindow(cus_t, ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, true);
				final TextView checkbox1 = cus_t.findViewById(R.id.checkbox1);
				
				final TextView checkbox2 = cus_t.findViewById(R.id.checkbox2);
				
				final LinearLayout linear1 = cus_t.findViewById(R.id.linear1);
				pop_up.showAsDropDown(circleimageview1, 0,0);
				if (str.equals("ON")) {
					checkbox1.setVisibility(View.GONE);
					checkbox2.setVisibility(View.VISIBLE);
				}
				else {
					if (str.equals("OFF")) {
						checkbox2.setVisibility(View.GONE);
						checkbox1.setVisibility(View.VISIBLE);
					}
					else {
						
					}
				}
				checkbox1.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View _view) {
						linear30.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF263238));
						linear30.setElevation((float)30);
						textview1.setTextColor(0xFFFFFFFF);
						
						linear19.setBackgroundColor(0xFF000000);
						checkbox1.setVisibility(View.GONE);
						checkbox2.setVisibility(View.VISIBLE);
						str = "ON";
					}
				});
				checkbox2.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View _view) {
						linear30.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFFECEFF1));
						linear30.setElevation((float)30);
						textview1.setTextColor(0xFF000000);
						
						linear19.setBackgroundColor(Color.TRANSPARENT);
						checkbox2.setVisibility(View.GONE);
						checkbox1.setVisibility(View.VISIBLE);
						str = "OFF";
					}
				});
			}
		});
		
		spinner1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
			@Override
			public void onItemSelected(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				
			}
			
			@Override
			public void onNothingSelected(AdapterView<?> _param1) {
				
			}
		});
		
		linear26.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				
			}
		});
		
		linear28.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				linear28.setVisibility(View.GONE);
				linear26.setVisibility(View.VISIBLE);
				FancyToast.makeText(MainActivity.this, "Disconnected Successfully!", FancyToast.LENGTH_LONG, FancyToast.SUCCESS, true).show();
				 ProfileManager.setConntectedVpnProfileDisconnected(MainActivity.this);
				  if (vpnService != null) {
						   vpnService.getManagement().stopVPN(false);
							   
						   }
			}
		});
		
		linear25.setOnLongClickListener(new View.OnLongClickListener() {
			@Override
			public boolean onLongClick(View _view) {
				
				return true;
			}
		});
		
		linear25.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				t = new TimerTask() {
					@Override
					public void run() {
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								net.startRequestNetwork(RequestNetworkController.GET, "https://www.google.com", "", _net_request_listener);
							}
						});
					}
				};
				_timer.schedule(t, (int)(1000));
				_Loading(true);
				FancyToast.makeText(MainActivity.this, "Please Wait Checking Network", FancyToast.LENGTH_LONG, FancyToast.INFO, true).show();
				linear26.setVisibility(View.GONE);
			}
		});
		
		_net_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				time = 0;
				spinner1.setEnabled(false);
				_connectServer();
				FancyToast.makeText(MainActivity.this, "Connected Successfully", FancyToast.LENGTH_LONG, FancyToast.SUCCESS, true).show();
				linear29.setVisibility(View.GONE);
				linear28.setVisibility(View.VISIBLE);
				_Loading(false);
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				linear29.setVisibility(View.GONE);
				linear26.setVisibility(View.VISIBLE);
				FancyToast.makeText(MainActivity.this, "Error Occurred Please Retry", FancyToast.LENGTH_LONG, FancyToast.ERROR, true).show();
				_Loading(false);
			}
		};
		
		_ner_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		_nett_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				startr = false;
				textview9.setText(String.valueOf((long)(ping)).concat("ms"));
				ti = new TimerTask() {
					@Override
					public void run() {
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								ping = 0;
								startr = true;
								_pingstart();
								nett.startRequestNetwork(RequestNetworkController.GET, "https://www.google.com/", "A", _nett_request_listener);
							}
						});
					}
				};
				_timer.schedule(ti, (int)(500));
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				startr = true;
				nett.startRequestNetwork(RequestNetworkController.GET, "https://www.google.com/", "A", _nett_request_listener);
				textview9.setTextColor(0xFF000000);
				textview9.setText("-- ms");
			}
		};
	}
	
	private void initializeLogic() {
		i.setClass(getApplicationContext(), PromoActivity.class);
		startActivity(i);
		linear29.setVisibility(View.GONE);
		preference = new SharedPreference(this);
		server = preference.getServer();
		LocalBroadcastManager.getInstance(this).registerReceiver(broadcastReceiver, new IntentFilter("connectionState")); 
		
		defaultUEH = Thread.getDefaultUncaughtExceptionHandler(); 
		Thread.setDefaultUncaughtExceptionHandler(unCaughtExceptionHandler);
		// I used exceptionhandler to solve a problem. the stop button was facing bugs so I tried to use handler so that if app gets crashed the it will launch itself smoothly even user will not understand it
		{
				final AssetManager conListA = MainActivity.this.getAssets();
				try {
						final String[] conListS = conListA.list("configs");
						conList = new ArrayList<String>(Arrays.asList(conListS));
				}catch(Exception e){}
		}
		spinner1.setAdapter(new ArrayAdapter<String>(getBaseContext(), android.R.layout.simple_spinner_dropdown_item, conList));
		((ArrayAdapter)spinner1.getAdapter()).notifyDataSetChanged();
		textview1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/zhxh.ttf"), 1);
		
		textview4.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/zhxh.ttf"), 1);
		textview3.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/zhxh.ttf"), 1);
		tt = new TimerTask() {
			@Override
			public void run() {
				runOnUiThread(new Runnable() {
					@Override
					public void run() {
						
						tt = new TimerTask() {
							@Override
							public void run() {
								runOnUiThread(new Runnable() {
									@Override
									public void run() {
										
										tt = new TimerTask() {
											@Override
											public void run() {
												runOnUiThread(new Runnable() {
													@Override
													public void run() {
														
														tt = new TimerTask() {
															@Override
															public void run() {
																runOnUiThread(new Runnable() {
																	@Override
																	public void run() {
																		
																	}
																});
															}
														};
														_timer.schedule(tt, (int)(100));
													}
												});
											}
										};
										_timer.schedule(tt, (int)(100));
									}
								});
							}
						};
						_timer.schedule(tt, (int)(100));
					}
				});
			}
		};
		_timer.schedule(tt, (int)(100));
		tt = new TimerTask() {
			@Override
			public void run() {
				runOnUiThread(new Runnable() {
					@Override
					public void run() {
						
						tt = new TimerTask() {
							@Override
							public void run() {
								runOnUiThread(new Runnable() {
									@Override
									public void run() {
										
										tt = new TimerTask() {
											@Override
											public void run() {
												runOnUiThread(new Runnable() {
													@Override
													public void run() {
														
														tt = new TimerTask() {
															@Override
															public void run() {
																runOnUiThread(new Runnable() {
																	@Override
																	public void run() {
																		
																	}
																});
															}
														};
														_timer.schedule(tt, (int)(100));
													}
												});
											}
										};
										_timer.schedule(tt, (int)(100));
									}
								});
							}
						};
						_timer.schedule(tt, (int)(100));
					}
				});
			}
		};
		_timer.schedule(tt, (int)(100));
		_rippleRoundStroke(linear25, "#0062fe", "#ffffff", 200, 0, "#000000");
		_rippleRoundStroke(linear26, "#cde0fd", "#cde0fd", 200, 0, "#000000");
		_rippleRoundStroke(linear28, "#0062fe", "#0062fe", 200, 0, "#000000");
		linear28.setVisibility(View.INVISIBLE);
		t = new TimerTask() {
			@Override
			public void run() {
				runOnUiThread(new Runnable() {
					@Override
					public void run() {
						ner.startRequestNetwork(RequestNetworkController.GET, "https://www.google.com", "", _ner_request_listener);
					}
				});
			}
		};
		_timer.scheduleAtFixedRate(t, (int)(0), (int)(100));
		startr = true;
		_pingstart();
		nett.startRequestNetwork(RequestNetworkController.GET, "https://www.google.com/", "A", _nett_request_listener);
		linear30.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFFECEFF1));
		linear30.setElevation((float)30);
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		if (_resultCode == RESULT_OK) {
				_start(conList.get((int)(spinner1.getSelectedItemPosition())));
		}
		else {
				Log.d(TAG, "onActivityResult: Permission Deny !!"); 
		}
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	public void _connectServer() {
		if (vpnStart) {
			showMessage("Already Connected");
			//sketchware toast
		}
		else {
			_prepareVPN();
		}
	}
	
	
	public void _startVPN() {
		try { // .ovpn file
			InputStream conf = getAssets().open("client.ovpn");
			//client.ovpn is your config file
			
			            InputStreamReader isr = new InputStreamReader(conf);
				 BufferedReader br = new BufferedReader(isr); 
				 String config = ""; 
				 String line; 
				 while (true) { 
						 line = br.readLine(); 
						 if (line == null) 
						 break; 
						 config += line + "\n"; 
						 } 
					 br.readLine(); 
					 OpenVpnApi.startVpn(this, config, server.getOvpnUserName(), server.getOvpnUserPassword()); 
					 // Update log
					  Log.d(TAG, "startVpn: Connecting "); 
					  vpnStart = true; 
					  } catch (IOException | RemoteException e) {
					   e.printStackTrace(); 
					   }
				   
	}
	
	
	public void _prepareVPN() {
		if (!vpnStart) {
			Intent intent = VpnService.prepare(this);
			if (intent != null) {
				startActivityForResult(intent, 1);
			}
			else {
				_startVPN();
				Log.d(TAG, "prepareVpn: connecting");
			}
		}
	}
	
	
	public void _borad() {
	}
	BroadcastReceiver broadcastReceiver = new BroadcastReceiver() {
		        @Override
		        public void onReceive(Context context, Intent intent) {
			            try {
				                Log.d(TAG, "onReceive: "+intent.getStringExtra("state"));
				            } catch (Exception e) {
				                e.printStackTrace();
				            }
			
			            try {
				
				                String duration = intent.getStringExtra("duration");
				                String lastPacketReceive = intent.getStringExtra("lastPacketReceive");
				                String byteIn = intent.getStringExtra("byteIn");
				                String byteOut = intent.getStringExtra("byteOut");
				
				                if (duration.equals(null)) duration = "00:00:00";
				                if (lastPacketReceive.equals(null)) lastPacketReceive = "0";
				                if (byteIn.equals(null)) byteIn = " ";
				                if (byteOut.equals(null)) byteOut = " ";
				                Log.d(TAG, "onReceive: "+duration+" "+ lastPacketReceive+" "+ byteIn+" "+ byteOut);
				            } catch (Exception e) {
				                e.printStackTrace();
				            }
			
			        }
		    };
		{
	}
	
	
	public void _d() {
		
			
	}
	    private ServiceConnection mConnection = new ServiceConnection() {
		        @Override
		        public void onServiceConnected(ComponentName className, IBinder service) {
			            // We've bound to LocalService, cast the IBinder and get LocalService instance
			            OpenVPNService.LocalBinder binder = (OpenVPNService.LocalBinder) service;
			            vpnService = binder.getService();
			        }
		
		        @Override
		        public void onServiceDisconnected(ComponentName arg0) {
			            vpnService = null;
			        }
		    };
	
	{
	}
	
	
	public void _df() {
		 }    private  Thread.UncaughtExceptionHandler unCaughtExceptionHandler = new Thread.UncaughtExceptionHandler(){
				@Override
		        public void uncaughtException(Thread thread, Throwable ex) {
			            // You can code here to send crash analytics
			            ex.printStackTrace();
						
						Intent intent = new Intent(MainActivity.this, MainActivity.class);
			        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
			        MainActivity.this.startActivity(intent);
			        if (MainActivity.this instanceof Activity) {
				            finish();
							Runtime.getRuntime().exit(0);
				        }
			            
			        }
				 };
	{
		
	}
	
	
	public void _start(final String _conFile) {
		try { // .ovpn file
			InputStream conf = getAssets().open("configs/"+_conFile);
			
			            InputStreamReader isr = new InputStreamReader(conf);
				 BufferedReader br = new BufferedReader(isr); 
				 String config = ""; 
				 String line; 
				 while (true) { 
						 line = br.readLine(); 
						 if (line == null) 
						 break; 
						 config += line + "\n"; 
						 } 
					 br.readLine(); 
					 OpenVpnApi.startVpn(this, config, server.getOvpnUserName(), server.getOvpnUserPassword()); 
					 // Update log
					  Log.d(TAG, "startVpn: Connecting "); 
					  vpnStart = true; 
					  } catch (IOException | RemoteException e) {
					   e.printStackTrace(); 
					   }
				   
	}
	
	
	public void _SetcornerRedius(final View _view, final double _radius, final double _shdow, final String _color) {
		android.graphics.drawable.GradientDrawable ab = new android.graphics.drawable.GradientDrawable();
		
		ab.setColor(Color.parseColor(_color));
		ab.setCornerRadius((float) _radius);
		_view.setElevation((float) _shdow);
		_view.setBackground(ab);
		
	}
	
	
	public void _ViewFadeIn(final View _viewFadeIn, final double _viewFadeInSetTime) {
		long x = (long)_viewFadeInSetTime;
		
		Animation fadeIn = new AlphaAnimation(0, 1); 
		fadeIn.setDuration(x);
		AnimationSet animation = new AnimationSet(true); animation.addAnimation(fadeIn);
		_viewFadeIn.startAnimation(animation);
	}
	
	
	public void _hell(final View _viewFadeIn, final double _viewFadeInSetTime) {
		long x = (long)_viewFadeInSetTime;
		
		Animation fadeIn = new AlphaAnimation(0, 1); 
		fadeIn.setDuration(x);
		AnimationSet animation = new AnimationSet(true); animation.addAnimation(fadeIn);
		_viewFadeIn.startAnimation(animation);
	}
	
	
	public void _rippleRoundStroke(final View _view, final String _focus, final String _pressed, final double _round, final double _stroke, final String _strokeclr) {
		android.graphics.drawable.GradientDrawable GG = new android.graphics.drawable.GradientDrawable();
		GG.setColor(Color.parseColor(_focus));
		GG.setCornerRadius((float)_round);
		GG.setStroke((int) _stroke,
		Color.parseColor("#" + _strokeclr.replace("#", "")));
		android.graphics.drawable.RippleDrawable RE = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{ Color.parseColor(_pressed)}), GG, null);
		_view.setBackground(RE);
	}
	
	
	public void _pingstart() {
		if (ping == 999) {
			textview9.setTextColor(0xFFF44336);
			textview9.setText("999".concat("ms"));
		}
		else {
			textview9.setTextColor(0xFF4CAF50);
			if (startr) {
				ping++;
				ping_timer = new TimerTask() {
					@Override
					public void run() {
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								_pingstart();
							}
						});
					}
				};
				_timer.schedule(ping_timer, (int)(1));
			}
		}
	}
	
	
	public void _Loading(final boolean _mode) {
		if (_mode) {
			
			
			if (coreprog == null){
				
				coreprog = new ProgressDialog(this);
				
				coreprog.setCancelable(false);
				
				coreprog.setCanceledOnTouchOutside(false);
				
				coreprog.requestWindowFeature(Window.FEATURE_NO_TITLE); coreprog.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
				
			}
			
			coreprog.show();
			
			coreprog.setContentView(R.layout.loading_cus);
			
			LinearLayout linear = (LinearLayout)coreprog.findViewById(R.id.linear);
			
			android.graphics.drawable.GradientDrawable JCBCJFG = new android.graphics.drawable.GradientDrawable();
			
			JCBCJFG.setColor(Color.parseColor("#FFFFFF"));
			
			JCBCJFG.setCornerRadius(100);
			
			linear.setBackground(JCBCJFG);
			
			
		}
		else {
			if (coreprog != null){
				
				coreprog.dismiss();
				
			}
			
			
		}
	}
	
	private ProgressDialog coreprog;
	
	{
		
		
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}